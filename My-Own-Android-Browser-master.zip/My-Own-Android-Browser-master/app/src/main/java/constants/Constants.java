package constants;

public class Constants {
    public static String URL_ADDRESS = "url_address";
}
